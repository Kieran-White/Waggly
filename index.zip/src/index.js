var callCreateAccountAPI = (username, password, location, number, checked)=>{
    if (checked) {
        type = "Walker";
    } else { type = "User";}
    // instantiate a headers object
    var myHeaders = new Headers();
    // add content type header to object
    myHeaders.append("Content-Type", "application/json");
    // using built in JSON utility package turn object to string and store in a variable
    var raw = JSON.stringify({"username":username, "password":password, "location":location, "number": number, "type": type});
    // create a JSON object with parameters for API call and store in a variable
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };
    // make API call with parameters and use promises to get response
    fetch("https://zxy498ya83.execute-api.eu-west-2.amazonaws.com/dev/api/register", requestOptions)
    .then(response => response.text())
    .catch(error => console.log('error', error));
}

function getOwnersDogs(ownername) {
    // instantiate a headers object
    var myHeaders = new Headers();
    // add content type header to object
    myHeaders.append("Content-Type", "application/json");
    // using built in JSON utility package turn object to string and store in a variable
    var raw = JSON.stringify({"ownername": ownername});
    // create a JSON object with parameters for API call and store in a variable
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };
    // make API call with parameters and use promises to get response
    fetch("https://zxy498ya83.execute-api.eu-west-2.amazonaws.com/dev/api/settings/getDog", requestOptions)
    .then(response => {
        if (response.ok) { return response.text();}
    })
    .then(result => {
        const parsedResult = JSON.parse(result).body;
        const dogArray = JSON.parse(parsedResult);

        // go through 2 of the items and enter the info into each display box
        for (var i = 1; i < 3; i++)  {
            var children = (document.getElementById(`dogContainer${i}`)).children;
            children[0].textContent = (dogArray[i-1].firstname) + " " + (dogArray[i-1].lastname);
            children[1].textContent = dogArray[i-1].breed;
            children[2].textContent = (dogArray[i-1].weight) + " kg";
        }


        // If 2 or more items then deactivate Enroll dog button
        if (dogArray.length >= 2) {
            document.getElementById("enrollDogButton").disabled = true;
        } else {
            document.getElementById("enrollDogButton").disabled = false;
        }

        })
    .catch(error => console.log('error', error));
}

async function getOwnerDetails(ownername) {
    try {
        // instantiate a headers object
        var myHeaders = new Headers();
        // add content type header to object
        myHeaders.append("Content-Type", "application/json");
        // using built-in JSON utility package turn object to string and store in a variable
        var raw = JSON.stringify({"ownername": ownername});
        // create a JSON object with parameters for API call and store in a variable
        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };
        // make API call with parameters and use await to get response
        const response = await fetch("https://zxy498ya83.execute-api.eu-west-2.amazonaws.com/dev/api/settings/getOwnerDetails", requestOptions);
        if (response.ok) {
            const result = await response.json();
            const body = JSON.parse(result.body);
            const location = body[0].location;
            const phone = body[0].phone;
            return [location, phone];
        }
    } catch (error) {
        console.log('error', error);
        return [null, null]; // handle error appropriately
    }
}

var callAddDogAPI = async (owner, fName, lName, breed, weight) => {
    try {
        ownername = owner.substring(6);
        const details = await getOwnerDetails(ownername);
        const ownLocation = details[0];
        const ownPhone = details[1];
        // instantiate a headers object
        var myHeaders = new Headers();
        // add content type header to object
        myHeaders.append("Content-Type", "application/json");
        // using built-in JSON utility package turn object to string and store in a variable
        var raw = JSON.stringify({"ownername": ownername, "firstname": fName, "lastname": lName, "breed": breed, "weight": weight, "location": ownLocation, "phone": ownPhone});
        // create a JSON object with parameters for API call and store in a variable
        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };
        // make API call with parameters and use await to get response
        const response = await fetch("https://zxy498ya83.execute-api.eu-west-2.amazonaws.com/dev/api/settings/addDog", requestOptions);
        setPage(document.querySelector("#settings-container"), document.querySelector("#home-container"));
    } catch (error) {
        console.log('error', error);
    }
}

function callLoginAPI (username, password, loginForm) {
    // instantiate a headers object
    var myHeaders = new Headers();
    // add content type header to object
    myHeaders.append("Content-Type", "application/json");
    // using built in JSON utility package turn object to string and store in a variable
    var raw = JSON.stringify({"username":username, "password":password});
    // create a JSON object with parameters for API call and store in a variable
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };
    // make API call with parameters and use promises to get response
    fetch("https://zxy498ya83.execute-api.eu-west-2.amazonaws.com/dev/api/login", requestOptions)
    .then(response => {if (response.ok){ return response.json();}})
    .then(result => {
        const bodyObj = JSON.stringify(result.statusCode);
            switch (bodyObj) {
                case '200':
                    setFormMessage(loginForm, "success", "Login Successful");
                    setPage(document.querySelector("#login-container"), document.querySelector("#home-container"));
                    document.querySelectorAll(".usernameLabel").forEach(ulabel => {ulabel.textContent = `User: ${username}`; });
                    break;
                case '401':
                case '404':
                    setFormMessage(loginForm, "error", "Invalid username/password combination");
                    break;
                default:
                    setFormMessage(loginForm, "error", "Unexpected Error");
                };
        })
        .catch(error => console.log('error', error));
}

function getDogWalkers(owner) {
    ownername = owner.substring(6);
// instantiate a headers object
    var myHeaders = new Headers();
    // add content type header to object
    myHeaders.append("Content-Type", "application/json");
    // using built in JSON utility package turn object to string and store in a variable
    var raw = JSON.stringify({"ownername": ownername});
    // create a JSON object with parameters for API call and store in a variable
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };
    // make API call with parameters and use promises to get response
    fetch("https://zxy498ya83.execute-api.eu-west-2.amazonaws.com/dev/api/getWalkers", requestOptions)
    .then(response => {if (response.ok){ return response.text();}})
    .then(result => {

        const parsedResult = JSON.parse(result).body;
        const walkerArray = JSON.parse(parsedResult);

        var table = document.getElementById("dogWalkers");
        //remove all rows apart from the first from above table
        while (table.rows.length > 1) {
            table.deleteRow(1);
        }

        walkerArray.forEach(walker => {
            var row = table.insertRow();

            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            var cell3 = row.insertCell(2);

            cell1.innerHTML = walker.ID;
            cell2.innerHTML = walker.location;
            cell3.innerHTML = walker.phone;
        });
        findPageButtonSwap(document.querySelector(".table__dogWalkers"), document.querySelector(".table__findDogs"))
        
        
    })
        .catch(error => console.log('error', error));
}

function getDogs(owner) {
    ownername = owner.substring(6);
    // instantiate a headers object
        var myHeaders = new Headers();
        // add content type header to object
        myHeaders.append("Content-Type", "application/json");
        // using built in JSON utility package turn object to string and store in a variable
        var raw = JSON.stringify({"ownername": ownername});
        // create a JSON object with parameters for API call and store in a variable
        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };
        // make API call with parameters and use promises to get response
        fetch("https://zxy498ya83.execute-api.eu-west-2.amazonaws.com/dev/api/getDogs", requestOptions)
        .then(response => {if (response.ok){ return response.text();}})
        .then(result => {
    
            const parsedResult = JSON.parse(result).body;
            const dogsArray = JSON.parse(parsedResult);
    
            var table = document.getElementById("findDogs");
            //remove all rows apart from the first from above table
            while (table.rows.length > 1) {
                table.deleteRow(1);
            }
    
            dogsArray.forEach(dog => {
                var row = table.insertRow();
    
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);
    
                cell1.innerHTML = dog.location;
                cell2.innerHTML = dog.firstname;
                cell3.innerHTML = dog.breed;
                cell4.innerHTML = (dog.weight + " kg");
                cell5.innerHTML = dog.ownername;
                cell6.innerHTML = dog.phone;
            });
            findPageButtonSwap(document.querySelector(".table__findDogs"), document.querySelector(".table__dogWalkers"))
            
            
        })
            .catch(error => console.log('error', error));
    }

function findPageButtonSwap(openPage, closePage) {
    closePage.classList.remove("form--hidden");
    openPage.classList.remove("form--hidden");
    closePage.classList.add("form--hidden");
}

function setFormMessage(formElement, type, message) {
    const messageElement = formElement.querySelector(".form__message");

    messageElement.textContent = message;
    messageElement.classList.remove("form__message--success", "form__message--error");
    messageElement.classList.add(`form__message--${type}`);
}

function setInputError(inputElement, message) {
    inputElement.classList.add("form__input--error");
    inputElement.parentElement.querySelector(".form__input-error-message").textContent = message;
}

function clearInputError(inputElement) {
    inputElement.classList.remove("form__input--error");
    inputElement.parentElement.querySelector(".form__input-error-message").textContent = "";
}

function setPage(prevPage, nextPage) {
    prevPage.classList.add("form--hidden");
    nextPage.classList.remove("form--hidden");
}

document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.querySelector("#login");
    const homeForm = document.querySelector("#home");
    const settingsForm = document.querySelector("#settings");
    const createAccountForm = document.querySelector("#createAccount");

    document.querySelector("#linkCreateAccount").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.add("form--hidden");
        createAccountForm.classList.remove("form--hidden");
    });

    document.querySelector("#linkLogin").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.remove("form--hidden");
        createAccountForm.classList.add("form--hidden");
    });

    document.addEventListener("button", e => {
        e.preventDefault();
    });

    loginForm.addEventListener("submit", e => {
        e.preventDefault();
        const username = loginForm.querySelector("#loginUsername").value;
        const password = loginForm.querySelector("#loginPassword").value;

        callLoginAPI(username, password, loginForm)
    });

    homeForm.addEventListener("submit", e => {
        e.preventDefault();
        setPage(document.querySelector("#home-container"), document.querySelector("#settings-container"));
        getOwnersDogs(document.getElementById('addDogUsername').textContent.substring(6));
    });

    settingsForm.addEventListener("submit", e => {
        e.preventDefault();
        setPage(document.querySelector("#settings-container"), document.querySelector("#home-container"));
    });

    document.querySelectorAll(".form__input").forEach(inputElement => {
        inputElement.addEventListener("blur", e => {
            if (e.target.id === "signupUsername" && e.target.value.length > 0 && e.target.value.length < 5) {
                setInputError(inputElement, "Username must be at least 5 Characters in length");
            };
            if (e.target.id === "signupPassword" && e.target.value.length > 0 && e.target.value.length < 5) {
                setInputError(inputElement, "Password must be at least 5 Characters in length");
            };
            if (e.target.id === "signupConfirmPassword" && e.target.value.length > 0 && e.target.value.length < 5) {
                setInputError(inputElement, "Password must be at least 5 Characters in length");
            };
            if (e.target.id === "signupConfirmPassword" && e.target.value !== document.querySelector("#signupPassword").value) {
                setInputError(inputElement, "Password Mismatch");
            }
        });

        inputElement.addEventListener("input", e => {
            clearInputError(inputElement);
        });
    });
});